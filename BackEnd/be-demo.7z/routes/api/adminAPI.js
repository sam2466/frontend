const myConnection = require("../Database/sqlConnect");

const tblName = "admin";

const Admin = {
    tblName: tblName,

    
}

module.exports = Admin;